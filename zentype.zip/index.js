"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.ts
var src_exports = {};
__export(src_exports, {
  default: () => ZenType
});
module.exports = __toCommonJS(src_exports);
var import_siyuan = require("siyuan");

// src/utils/getCursorRect.ts
function getCursorRect() {
  const sel = window.getSelection();
  if (!sel || sel.rangeCount === 0) return null;
  const range = sel.getRangeAt(0).cloneRange();
  range.collapse(true);
  const rects = Array.from(range.getClientRects());
  if (rects.length > 0) {
    return rects[rects.length - 1];
  }
  try {
    const marker = document.createTextNode("\u200B");
    range.insertNode(marker);
    const rect = marker.getBoundingClientRect();
    marker.remove();
    return rect;
  } catch {
    return null;
  }
}
function getCursorElement() {
  const sel = window.getSelection();
  if (!sel || sel.rangeCount === 0) return null;
  const range = sel.getRangeAt(0);
  const container = range.startContainer;
  return container.nodeType === Node.TEXT_NODE ? container.parentElement : container;
}

// src/utils/styleManager.ts
var styleMap = /* @__PURE__ */ new Map();
function addStyle(id, css) {
  if (styleMap.has(id)) {
    console.warn(`[zenType] style "${id}" already added`);
    return;
  }
  const style = document.createElement("style");
  style.id = `zentype-${id}`;
  style.textContent = css;
  document.head.appendChild(style);
  styleMap.set(id, style);
}
function removeStyle(id) {
  const style = styleMap.get(id);
  if (style) {
    style.remove();
    styleMap.delete(id);
  }
}

// src/styles/index.scss
var styles_default = {};

// src/modules/cursor.ts
var STYLE_ID = "cursor";
var CURSOR_ID = "zentype-cursor";
var BLINK_DELAY = 500;
var cursorEl = null;
var blinkTimer = null;
var pendingFrame = null;
var eventListeners = [];
var blinkListeners = [];
var wsHandler = null;
function createCursorElement() {
  let el = document.getElementById(CURSOR_ID);
  if (el) return el;
  el = document.createElement("div");
  el.id = CURSOR_ID;
  el.classList.add("hidden");
  document.body.appendChild(el);
  return el;
}
function updateCursor() {
  if (!cursorEl || pendingFrame !== null) return;
  pendingFrame = requestAnimationFrame(() => {
    pendingFrame = null;
    if (!cursorEl) return;
    const rect = getCursorRect();
    if (!rect || rect.width === 0) {
      cursorEl.classList.add("hidden");
      return;
    }
    cursorEl.style.transform = `translate3d(${rect.left}px, ${rect.top}px, 0)`;
    cursorEl.style.height = `${rect.height}px`;
    cursorEl.classList.remove("hidden");
  });
}
function startBlink() {
  if (!cursorEl) return;
  if (blinkTimer !== null) clearTimeout(blinkTimer);
  blinkTimer = window.setTimeout(() => {
    cursorEl?.classList.add("breathing");
  }, BLINK_DELAY);
}
function stopBlink() {
  if (blinkTimer !== null) {
    clearTimeout(blinkTimer);
    blinkTimer = null;
  }
  cursorEl?.classList.remove("breathing");
}
function initCursor() {
  cursorEl = createCursorElement();
  addStyle(STYLE_ID, styles_default);
  const handlers = [
    ["selectionchange", updateCursor],
    ["keyup", updateCursor],
    ["keydown", updateCursor],
    ["mouseup", updateCursor],
    ["click", updateCursor],
    ["scroll", updateCursor, { passive: true }],
    ["wheel", updateCursor, { passive: true }],
    ["resize", updateCursor]
  ];
  handlers.forEach(([event, handler, options]) => {
    document.addEventListener(event, handler, options);
  });
  eventListeners = handlers;
  blinkListeners = [
    ["selectionchange", stopBlink],
    ["keydown", stopBlink],
    ["mousedown", stopBlink]
  ];
  blinkListeners.forEach(([event, handler]) => {
    document.addEventListener(event, handler);
  });
  if (window.siyuan?.ws?.ws) {
    wsHandler = (e) => {
      try {
        const msg = JSON.parse(e.data);
        if (msg.cmd === "transactions") {
          updateCursor();
        }
      } catch {
      }
    };
    window.siyuan.ws.ws.addEventListener("message", wsHandler);
  }
  startBlink();
  updateCursor();
}
function destroyCursor() {
  eventListeners.forEach(([event, handler]) => {
    document.removeEventListener(event, handler);
  });
  eventListeners = [];
  blinkListeners.forEach(([event, handler]) => {
    document.removeEventListener(event, handler);
  });
  blinkListeners = [];
  if (wsHandler && window.siyuan?.ws?.ws) {
    window.siyuan.ws.ws.removeEventListener("message", wsHandler);
    wsHandler = null;
  }
  stopBlink();
  if (pendingFrame !== null) {
    cancelAnimationFrame(pendingFrame);
    pendingFrame = null;
  }
  if (cursorEl) {
    cursorEl.remove();
    cursorEl = null;
  }
  removeStyle(STYLE_ID);
}

// src/utils/edgeCases.ts
function hasSelection() {
  const sel = window.getSelection();
  return (sel?.toString().length ?? 0) > 0;
}
function isReadMode() {
  const editor = document.querySelector(".protyle-content");
  return !editor || !editor.isContentEditable;
}
function isInPopup() {
  return !!document.querySelector(".block__popover--open");
}
function isInEmbedBlock() {
  const cursor = getCursorElement();
  if (!cursor) return false;
  return !!cursor.closest(
    "iframe, video, [data-type='NodeIFrame'], [data-type='NodeVideo'], [data-type='NodePDF']"
  );
}
function shouldPauseFocusAndTypewriter() {
  if (hasSelection()) return true;
  if (isInPopup()) return true;
  return false;
}
function shouldPauseTypewriter() {
  if (isInPopup()) return true;
  if (isReadMode()) return true;
  if (isInEmbedBlock()) return true;
  return false;
}

// src/modules/typewriter.ts
var STYLE_ID2 = "typewriter";
var HIGHLIGHT_ID = "zentype-highlight-line";
var TARGET_RATIO = 0.38;
var THRESHOLD = 40;
var DURATION = 400;
var highlightEl = null;
var eventListeners2 = [];
var pendingScroll = null;
function easeInOutCubic(t) {
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}
function getEditorContainer() {
  return document.querySelector(".protyle:not(.fn__none) .protyle-content");
}
function createHighlightElement() {
  let el = document.getElementById(HIGHLIGHT_ID);
  if (el) return el;
  el = document.createElement("div");
  el.id = HIGHLIGHT_ID;
  document.body.appendChild(el);
  return el;
}
function getEditorZIndex() {
  const container = getEditorContainer();
  if (!container) return 0;
  const computed = window.getComputedStyle(container).zIndex;
  const parsed = Number.parseInt(computed, 10);
  return Number.isFinite(parsed) ? parsed : 0;
}
function updateHighlight(rect) {
  if (!highlightEl) return;
  const editorZ = getEditorZIndex();
  highlightEl.style.zIndex = String(Math.max(editorZ + 1, 1e3));
  highlightEl.style.transform = `translate3d(0, ${rect.top - 4}px, 0)`;
  highlightEl.style.height = `${rect.height + 8}px`;
  highlightEl.style.left = `${rect.left}px`;
  highlightEl.style.width = `${rect.width || 100}px`;
  highlightEl.classList.add("visible");
}
function smoothScroll(target, deltaY) {
  if (pendingScroll !== null) cancelAnimationFrame(pendingScroll);
  const startScroll = target.scrollTop;
  const endScroll = startScroll + deltaY;
  const startTime = performance.now();
  function step() {
    const elapsed = performance.now() - startTime;
    const t = Math.min(elapsed / DURATION, 1);
    const eased = easeInOutCubic(t);
    target.scrollTop = startScroll + (endScroll - startScroll) * eased;
    if (t < 1) {
      pendingScroll = requestAnimationFrame(step);
    } else {
      pendingScroll = null;
    }
  }
  pendingScroll = requestAnimationFrame(step);
}
function checkAndScroll() {
  if (shouldPauseTypewriter()) {
    highlightEl?.classList.remove("visible");
    return;
  }
  const rect = getCursorRect();
  if (!rect) {
    highlightEl?.classList.remove("visible");
    return;
  }
  const container = getEditorContainer();
  if (!container) return;
  updateHighlight(rect);
  const containerRect = container.getBoundingClientRect();
  const targetY = containerRect.top + containerRect.height * TARGET_RATIO;
  const offset = rect.top - targetY;
  if (Math.abs(offset) >= THRESHOLD) {
    smoothScroll(container, offset);
  }
}
function initTypewriter() {
  highlightEl = createHighlightElement();
  addStyle(STYLE_ID2, styles_default);
  const handlers = [
    ["selectionchange", checkAndScroll],
    ["keyup", checkAndScroll],
    ["keydown", checkAndScroll],
    ["click", checkAndScroll],
    ["mouseup", checkAndScroll],
    ["resize", checkAndScroll]
  ];
  handlers.forEach(([event, handler, options]) => {
    document.addEventListener(event, handler, options);
  });
  eventListeners2 = handlers;
}
function destroyTypewriter() {
  eventListeners2.forEach(([event, handler]) => {
    document.removeEventListener(event, handler);
  });
  eventListeners2 = [];
  if (pendingScroll !== null) {
    cancelAnimationFrame(pendingScroll);
    pendingScroll = null;
  }
  if (highlightEl) {
    highlightEl.remove();
    highlightEl = null;
  }
  removeStyle(STYLE_ID2);
}

// src/modules/ripple.ts
var OPACITY_LEVELS = [1, 0.85, 0.6, 0.35, 0.15, 0.05];
var MOUSE_THROTTLE = 100;
var IDLE_THRESHOLD = 2e3;
var SCROLLBAR_MARGIN = 20;
var mode = "text";
var lastTextCursorChange = 0;
var lastMouseBlock = null;
var lastTextBlock = null;
var pendingFrame2 = null;
var eventListeners3 = [];
var lastMouseMove = 0;
function getCurrentBlock() {
  if (mode === "mouse" && lastMouseBlock) return lastMouseBlock;
  const cursor = getCursorElement();
  return cursor?.closest("[data-node-id]") ?? null;
}
function calculateBlockDistance(from, to) {
  const fromParent = from.parentElement;
  if (!fromParent) return 0;
  const siblings = Array.from(fromParent.children);
  const fromIndex = siblings.indexOf(from);
  const toIndex = siblings.indexOf(to);
  return Math.abs(fromIndex - toIndex);
}
function isOverScrollbar(e) {
  const w = window.innerWidth;
  const h = window.innerHeight;
  return e.clientX > w - SCROLLBAR_MARGIN || e.clientY > h - SCROLLBAR_MARGIN;
}
function applyRipple() {
  if (pendingFrame2 !== null) return;
  pendingFrame2 = requestAnimationFrame(() => {
    pendingFrame2 = null;
    if (shouldPauseFocusAndTypewriter()) {
      clearAllOpacity();
      return;
    }
    const currentBlock = getCurrentBlock();
    if (!currentBlock) return;
    const container = currentBlock.closest(".protyle-wysiwyg");
    if (!container) return;
    const allBlocks = Array.from(
      container.querySelectorAll("[data-node-id], iframe, video")
    );
    allBlocks.forEach((block) => {
      const distance = calculateBlockDistance(currentBlock, block);
      const opacity = OPACITY_LEVELS[Math.min(distance, OPACITY_LEVELS.length - 1)];
      block.style.opacity = String(opacity);
    });
    currentBlock.style.opacity = "1";
  });
}
function clearAllOpacity() {
  const blocks = document.querySelectorAll(
    ".protyle-wysiwyg [data-node-id], .protyle-wysiwyg iframe, .protyle-wysiwyg video"
  );
  blocks.forEach((block) => {
    block.style.opacity = "";
  });
}
function onSelectionChange() {
  lastTextCursorChange = Date.now();
  const cursor = getCursorElement();
  lastTextBlock = cursor?.closest("[data-node-id]") ?? null;
  if (mode !== "paused") {
    mode = "text";
    applyRipple();
  }
}
function onMouseMove(e) {
  const now = Date.now();
  if (now - lastMouseMove < MOUSE_THROTTLE) return;
  lastMouseMove = now;
  const target = e.target;
  if (!target?.closest(".protyle-wysiwyg")) {
    if (mode === "mouse") {
      mode = "text";
      applyRipple();
    }
    return;
  }
  if (isOverScrollbar(e)) return;
  const elementAtPoint = document.elementFromPoint(e.clientX, e.clientY);
  if (!elementAtPoint) return;
  const mouseBlock = elementAtPoint.closest("[data-node-id], iframe, video");
  if (!mouseBlock) return;
  lastMouseBlock = mouseBlock;
  const readMode = isReadMode();
  const idleTooLong = now - lastTextCursorChange > IDLE_THRESHOLD;
  const mouseInDifferentBlock = lastTextBlock && !mouseBlock.contains(lastTextBlock) && !lastTextBlock.contains(mouseBlock);
  if (readMode || idleTooLong || mouseInDifferentBlock) {
    if (mode !== "mouse") {
      mode = "mouse";
    }
    applyRipple();
  }
}
function initRipple() {
  mode = "text";
  lastTextCursorChange = Date.now();
  lastMouseBlock = null;
  lastTextBlock = null;
  pendingFrame2 = null;
  lastMouseMove = 0;
  const handlers = [
    ["selectionchange", onSelectionChange],
    ["mousemove", onMouseMove, { passive: true }],
    ["click", onSelectionChange],
    ["keyup", onSelectionChange]
  ];
  handlers.forEach(([event, handler, options]) => {
    document.addEventListener(event, handler, options);
  });
  eventListeners3 = handlers;
  applyRipple();
}
function destroyRipple() {
  eventListeners3.forEach(([event, handler]) => {
    document.removeEventListener(event, handler);
  });
  eventListeners3 = [];
  if (pendingFrame2 !== null) {
    cancelAnimationFrame(pendingFrame2);
    pendingFrame2 = null;
  }
  clearAllOpacity();
  mode = "text";
  lastMouseBlock = null;
  lastTextBlock = null;
}

// src/index.ts
var STORAGE_KEY = "zentype-enabled";
var ICON_SVG = `<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>`;
var ZenType = class extends import_siyuan.Plugin {
  enabled = {
    cursor: true,
    typewriter: true,
    ripple: true
  };
  async onload() {
    const saved = await this.loadData(STORAGE_KEY);
    if (saved && typeof saved === "object") {
      this.enabled = { ...this.enabled, ...saved };
    }
    this.addCommand({
      langKey: "toggle-cursor",
      callback: () => this.toggle("cursor")
    });
    this.addCommand({
      langKey: "toggle-typewriter",
      callback: () => this.toggle("typewriter")
    });
    this.addCommand({
      langKey: "toggle-ripple",
      callback: () => this.toggle("ripple")
    });
    this.addCommand({
      langKey: "toggle-all",
      callback: () => this.toggleAll()
    });
    const allOn = this.isAllEnabled();
    this.addTopBar({
      icon: ICON_SVG,
      title: allOn ? "zenType \u5DF2\u542F\u7528" : "zenType \u5DF2\u7981\u7528",
      callback: () => this.toggleAll()
    });
    if (this.enabled.cursor) initCursor();
    if (this.enabled.typewriter) initTypewriter();
    if (this.enabled.ripple) initRipple();
    console.log("zenType v2 loaded");
  }
  onunload() {
    destroyCursor();
    destroyTypewriter();
    destroyRipple();
    console.log("zenType v2 unloaded");
  }
  toggle(name) {
    this.enabled[name] = !this.enabled[name];
    if (name === "cursor") {
      if (this.enabled.cursor) initCursor();
      else destroyCursor();
    } else if (name === "typewriter") {
      if (this.enabled.typewriter) initTypewriter();
      else destroyTypewriter();
    } else if (name === "ripple") {
      if (this.enabled.ripple) initRipple();
      else destroyRipple();
    }
    this.saveData(STORAGE_KEY, this.enabled);
  }
  toggleAll() {
    const allOn = this.isAllEnabled();
    const newState = !allOn;
    if (newState && !this.enabled.cursor) {
      this.enabled.cursor = true;
      initCursor();
    } else if (!newState && this.enabled.cursor) {
      this.enabled.cursor = false;
      destroyCursor();
    }
    if (newState && !this.enabled.typewriter) {
      this.enabled.typewriter = true;
      initTypewriter();
    } else if (!newState && this.enabled.typewriter) {
      this.enabled.typewriter = false;
      destroyTypewriter();
    }
    if (newState && !this.enabled.ripple) {
      this.enabled.ripple = true;
      initRipple();
    } else if (!newState && this.enabled.ripple) {
      this.enabled.ripple = false;
      destroyRipple();
    }
    this.saveData(STORAGE_KEY, this.enabled);
  }
  isAllEnabled() {
    return this.enabled.cursor && this.enabled.typewriter && this.enabled.ripple;
  }
};
//# sourceMappingURL=index.js.map
